# ASIGNACIÓN 1 #
Web Design: Altos de Chavón School of Design

Tomar plantilla entregada en clase y modificar para crear una biografía de cada estudiante. El estudiante deberá solo cambiar la imagen por una suya, incluir un párrafo sobre el/ella e incluir trabajos de primer año. Estas plantillas serán utilizadas para crear un portal de la Asignatura “Web Design” en Altos de Chavón. Tener en cuenta la ortografía en la presentación de los trabajos. Incluir sus redes, instagram, github y linkedin. El estudiante que no tenga una cuenta de linkedin debe de crear una.
 
El estudiante deberá traer a clase un zip con su plantilla organizada como se le entregó. También debe de investigar sobre códigos desconocidos dentro de la plantilla y formular preguntas sobre su descubrimiento en una hoja impresa 8.5” x 11”.
